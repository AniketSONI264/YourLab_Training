import crypto from "crypto";
import fs from "fs/promises";
import cloudinary from "cloudinary";
import asyncHandler from "../middlewares/asyncHandler.middleware.js";
import AppError from "../utils/AppError.js";
import { ApiResponse } from "../utils/ApiResponse.js";
import Doctor from "../models/doctor.model.js";
import sendEmail from "../utils/sendEmail.js";
import Appointment from "../models/appointment.models.js";

const cookieOptions = {
  secure: process.env.NODE_ENV === "production" ? true : false,
  maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
  httpOnly: true,
  SameSite: "none",
};

/**
 * @REGISTER
 * @ROUTE @POST {{URL}}/api/v1/user/register
 * @ACCESS Public
 */


export const registerUser = asyncHandler(async (req, res, next) => {
  // Destructuring the necessary data from req object
  const {
    fullName,
    email,
    password,
    specialist,
    description,
    mobileNumber,
    address,
    pincode,fees
  } = req.body;
  console.log(fullName, email, password, specialist);
  // Check if the data is there or not, if not throw error message
  if (
    !fullName ||
    !email ||
    !password ||
    !specialist ||
    !description ||
    !mobileNumber ||
    !address ||
    !pincode
  ) {
    return next(new AppError("All fields are required", 400));
  }

  // Check if the user exists with the provided email
  const userExists = await Doctor.findOne({ email });

  // If user exists send the response
  if (userExists) {
    return next(new AppError("Email already exists", 409));
  }

  // Create new user with the given necessary data and save to DB
  const user = await Doctor.create({
    fullName,
    email,
    password,
    specialist,
    description,
    mobileNumber,
    address,
    pincode,
    fees:{
    firstVisitFee : fees,
    secondVisitFee:fees,
    visitUnder7DaysFee:fees,
    emergencyFee1:fees,
    emergencyFee2:fees,
    },
    avatar: {
      public_id: email,
      secure_url:
        "https://res.cloudinary.com/du9jzqlpt/image/upload/v1674647316/avatar_drzgxv.jpg",
    },
  });
  // If user not created send message response
  if (!user) {
    return next(
      new AppError("User registration failed, please try again later", 400)
    );
  }
  // Run only if user sends a file
  if (req.file) {
    try {
      const result = await cloudinary.v2.uploader.upload(req.file.path, {
        folder: "lms", // Save files in a folder named lms
        width: 250,
        height: 250,
        gravity: "faces", // This option tells cloudinary to center the image around detected faces (if any) after cropping or resizing the original image
        crop: "fill",
      });

      // If success
      if (result) {
        // Set the public_id and secure_url in DB
        user.avatar.public_id = result.public_id;
        user.avatar.secure_url = result.secure_url;

        // After successful upload remove the file from local storage
        fs.rm(`uploads/${req.file.filename}`);
      }
    } catch (error) {}
  }

  // Save the user object
  await user.save();

  // Generating a JWT token
  const token = await user.generateJWTToken();
  console.log(token);

  // Setting the password to undefined so it does not get sent in the response
  user.password = undefined;

  // Setting the token in the cookie with name token along with cookieOptions
  res.cookie("token", token, cookieOptions);

  // If all good send the response to the frontend
  res.status(201).json(new ApiResponse(200, user, "User created successfully"));
});



/**
 * @LOGIN
 * @ROUTE @POST {{URL}}/api/v1/user/login
 * @ACCESS Public
 */
export const loginUser = asyncHandler(async (req, res, next) => {
  // Destructuring the necessary data from req object
  const { email, password } = req.body;

  // Check if the data is there or not, if not throw error message
  if (!email || !password) {
    return next(new AppError("Email and Password are required", 400));
  }

  // Finding the user with the sent email
  const user = await Doctor.findOne({ email }).select("+password");

  // If no user or sent password do not match then send generic response
  if (!(user && (await user.comparePassword(password)))) {
    return next(
      new AppError("Email or Password do not match or user does not exist", 401)
    );
  }


  await user.save();

  // Generating a JWT token
  const token = await user.generateJWTToken();

  // Setting the password to undefined so it does not get sent in the response
  user.password = undefined;

  // Setting the token in the cookie with name token along with cookieOptions
  res.cookie("token", token, cookieOptions);

  // If all good send the response to the frontend
  res.status(200).json(new ApiResponse(200, user, "user login successfully"));
});

/**
 * @LOGOUT
 * @ROUTE @POST {{URL}}/api/v1/user/logout
 * @ACCESS Public
 */

export const logoutUser = asyncHandler(async (req, res, next) => {
  // Setting the cookie value to null
  res.cookie("token", null, {
    secure: process.env.NODE_ENV === "production" ? true : false,
    maxAge: 0,
    httpOnly: true,
  });

  // Sending the response
  res.status(200).json({
    success: true,
    message: "User logged out successfully",
  });
});

/**
 * @LOGGED_IN_USER_DETAILS
 * @ROUTE @GET {{URL}}/api/v1/user/me
 * @ACCESS Private(Logged in users only)
 */
export const getLoggedInUserDetails = asyncHandler(async (req, res, _next) => {
  // Finding the user using the id from modified req object
  const user = await Doctor.findById(req.user.id);
  console.log(user);

  res.status(200).json({
    success: true,
    message: "User details",
    user,
  });
});

/**
 * @FORGOT_PASSWORD
 * @ROUTE @POST {{URL}}/api/v1/user/reset
 * @ACCESS Public
 */
export const forgotPassword = asyncHandler(async (req, res, next) => {
  // Extracting email from request body
  const { email } = req.body;

  // If no email send email required message
  if (!email) {
    return next(new AppError("Email is required", 400));
  }

  // Finding the user via email
  const user = await Doctor.findOne({ email });

  // If no email found send the message email not found
  if (!user) {
    return next(new AppError("Email not registered", 400));
  }

  // Generating the OTP via the method we created earlier
  const otp = await user. generatePasswordResetToken();
  console.log(otp)

  // Saving the forgotPassword* fields to DB
  await user.save();

  // We need to send an email to the user with the OTP
  const subject = "Your Password Reset OTP";
  const message = `Your OTP for resetting your password is: ${otp}\n\nThis OTP is valid for 15 minutes.\nIf you did not request this, please ignore this email.`;

  try {
    await sendEmail(email, subject, message);

    // If email sent successfully send the success response
    res.status(200).json({
      success: true,
      message: `Password reset OTP has been sent to ${email} successfully`,
    });
  } catch (error) {
    // If some error happened we need to clear the forgotPassword* fields in our DB
    user.forgotPasswordToken = undefined;
    user.forgotPasswordExpiry = undefined;

    await user.save();

    return next(
      new AppError(
        error.message || "Something went wrong, please try again.",
        500
      )
    );
  }
});

export const tokenCheck =asyncHandler(async(req,res,next)=>{

  const {resetToken} = req.params;
  const forgotPasswordToken = crypto
  .createHash("sha256")
  .update(resetToken)
  .digest("hex");

  console.log(forgotPasswordToken);

  // Checking if token matches in DB and if it is still valid(Not expired)
  const user = await Doctor.findOne({
    forgotPasswordToken,
    forgotPasswordExpiry: { $gt: Date.now() }, // $gt will help us check for greater than value, with this we can check if token is valid or expired
  });

  // If not found or expired send the response
  if (!user) {
    return next(
      new AppError("Token is invalid or expired, please try again", 400)
    );
  }
  res.status(200).json({
    success: true,
    message: "Otp matched  successfully",
  });

})
/**
 * @RESET_PASSWORD
 * @ROUTE @POST {{URL}}/api/v1/user/reset/:resetToken
 * @ACCESS Public
 */
export const resetPassword = asyncHandler(async (req, res, next) => {
  // Extracting resetToken from req.params object
  const { resetToken } = req.params;
  // console.log(resetToken)

  // Extracting password from req.body object
  const { password } = req.body;
  // console.log( 'passward  is ',password)

  // We are again hashing the resetToken using sha256 since we have stored our resetToken in DB using the same algorithm
  const forgotPasswordToken = crypto
    .createHash("sha256")
    .update(resetToken)
    .digest("hex");

  // Check if password is not there then send response saying password is required
  if (!password) {
    return next(new AppError("Password is required", 400));
  }

  console.log(forgotPasswordToken);

  // Checking if token matches in DB and if it is still valid(Not expired)
  const user = await Doctor.findOne({
    forgotPasswordToken,
    forgotPasswordExpiry: { $gt: Date.now() }, // $gt will help us check for greater than value, with this we can check if token is valid or expired
  });

  // If not found or expired send the response
  if (!user) {
    return next(
      new AppError("Token is invalid or expired, please try again", 400)
    );
  }

  // Update the password if token is valid and not expired
  user.password = password;

  // making forgotPassword* valus undefined in the DB
  user.forgotPasswordExpiry = undefined;
  user.forgotPasswordToken = undefined;

  // Saving the updated user values
  await user.save();

  // Sending the response when everything goes good
  res.status(200).json({
    success: true,
    message: "Password changed successfully",
  });
});

/**
 * @CHANGE_PASSWORD
 * @ROUTE @POST {{URL}}/api/v1/user/change-password
 * @ACCESS Private (Logged in users only)
 */
export const changePassword = asyncHandler(async (req, res, next) => {
  // Destructuring the necessary data from the req object
  const { oldPassword, newPassword } = req.body;
  // console.log(oldPassword,newPassword)
  const { id } = req.user; // because of the middleware isLoggedIn

  // Check if the values are there or not
  if (!oldPassword || !newPassword) {
    return next(
      new AppError("Old password and new password are required", 400)
    );
  }

  // Finding the user by ID and selecting the password
  const user = await Doctor.findById(id).select("+password");

  // If no user then throw an error message
  if (!user) {
    return next(new AppError("Invalid user id or user does not exist", 400));
  }

  // Check if the old password is correct
  const isPasswordValid = await user.comparePassword(oldPassword);

  // If the old password is not valid then throw an error message
  if (!isPasswordValid) {
    return next(new AppError("Invalid old password", 400));
  }

  // Setting the new password
  user.password = newPassword;

  // Save the data in DB
  await user.save();

  // Setting the password undefined so that it won't get sent in the response
  user.password = undefined;

  res.status(200).json({
    success: true,
    message: "Password changed successfully",
  });
});

/**
 * @UPDATE_USER
 * @ROUTE @POST {{URL}}/api/v1/user/update/:id
 * @ACCESS Private (Logged in user only)
 */
export const updateUser = asyncHandler(async (req, res, next) => {
  // Destructuring the necessary data from the req object
  const { fullName,description,address,pincode,mobileNumber,fees,joinStatus } = req.body;
  const id = req.user.id;

  const doctor = await Doctor.findById(id);

  if (!doctor) {
    return next(new AppError("Invalid user id or user does not exist"));
  }

  doctor.fullName = fullName;
  doctor.description = description;
  doctor.address = address;
  doctor.pincode = pincode;
  doctor.mobileNumber = mobileNumber;
  doctor.fees.firstVisitFee = fees;
  doctor.joinStatus = joinStatus

  // Run only if user sends a file
  if (req.file) {
    // Deletes the old image uploaded by the user
    await cloudinary.v2.uploader.destroy(doctor.avatar.public_id);

    try {
      const result = await cloudinary.v2.uploader.upload(req.file.path, {
        folder: "lms", // Save files in a folder named lms
        width: 250,
        height: 250,
        gravity: "faces", // This option tells cloudinary to center the image around detected faces (if any) after cropping or resizing the original image
        crop: "fill",
      });

      // If success
      if (result) {
        // Set the public_id and secure_url in DB
        doctor.avatar.public_id = result.public_id;
        doctor.avatar.secure_url = result.secure_url;

        // After successful upload remove the file from local storage
        fs.rm(`uploads/${req.file.filename}`);
      }
    } catch (error) {
      return next(
        new AppError(error || "File not uploaded, please try again", 400)
      );
    }
  }

  // Save the user object
  await doctor.save();

  res
  .status(201)
  .json(
    new ApiResponse(200, doctor, " Doctor profile update successfully ")
  );
});

export const activeStatus = asyncHandler(async (req,res,next)=>{
  const {status} = req.body;

  const doctor = await Doctor.findById(req.user.id)
  if(!doctor){
    return next(new AppError("Doctor not found", 404))
  }
  doctor.status = status;
  await doctor.save()
  res
    .status(200)
    .json(new ApiResponse(200, doctor, `Doctor is ${status}`));

})

export const getAllDoctors = asyncHandler(async (req, res, next) => {
  const doctors = await Doctor.find({});
  res
    .status(200)
    .json(new ApiResponse(200, doctors, "Doctors fetched successfully"));
});

export const getAppointments = asyncHandler(async (req, res, next) => {
  const doctorId = req.user.id; // assuming req.doctor is set in middleware
  const appointments = await Appointment.find({ doctorId });

  res.status(200).json({
    success: true,
    count: appointments.length,
    data: appointments,
    message: "appointment fetched successfully",
  });
});

function generateRandomID(patientName, appointmentDate) {
  // Function to generate a random alphanumeric character
  function getRandomChar() {
    const chars =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    return chars.charAt(Math.floor(Math.random() * chars.length));
  }

  // Ensure patientName has at least 2 characters
  const namePart = patientName.slice(0, 2).toUpperCase();

  // Extract day, month, and year from the appointmentDate
  const [day, month, year] = appointmentDate.split("/");

  // Ensure appointmentMonth is two digits
  const monthPart = ("0" + month).slice(-2);

  // Ensure appointmentYear is four digits
  const yearPart = ("000" + year).slice(-4);

  // Generate the rest of the ID with random characters to reach 12 characters in total
  const randomPartLength =
    14 - namePart.length - monthPart.length - yearPart.length;
  let randomPart = "";
  for (let i = 0; i < randomPartLength; i++) {
    randomPart += getRandomChar();
  }

  // Combine all parts to form the final ID
  const id = namePart + yearPart + monthPart + randomPart;

  return id;
}

export const newAppointmentByDoctor = asyncHandler(async (req, res, next) => {
  const {
    patientName,
    patientPhone,
    age,
    gender,
    description,
    date,
    time,
    bloodPressure,
    diabetes,
    weight,
  
  } = req.body;
  const patientId = generateRandomID(patientName, date);
  const doctorId = req.user.id;
  if (!patientName || !patientPhone || !age || !gender || !date || !time) {
    throw new AppError(400, "All fields are required ");
  }
  let mode = "Doctor"

  const appointment = await Appointment.create({
    doctorId,
    patientName,
    patientPhone,
    age,
    gender,
    description,
    date,
    time,
    patientId,
    bloodPressure,
    diabetes,
    weight,
    mode,
    status:"Accepted"
  });
  if (!appointment) {
    return next(new AppError("Failed to create appointment", 400));
  }
  res
    .status(201)
    .json(
      new ApiResponse(200, appointment, "Appointment by doctor successfully ")
    );
});

export const updateAppointmentByDoctor = asyncHandler(async (req, res, next) => {
  const {
    description,
    
    bloodPressure,
    diabetes,
    weight,
  } = req.body;

  const {appointmentId} = req.params;




  const appointment = await Appointment.findById(appointmentId);
  if(!appointment){
    throw new AppError(400, "Appointment does not exist");
  }

  appointment.description = description;
  appointment.bloodPressure = bloodPressure;
  appointment.diabetes = diabetes;
  appointment.weight = weight;
  await appointment.save();
  res
    .status(201)
    .json(
      new ApiResponse(200, appointment, "Appointment update by doctor successfully ")
    );
});

// Update doctor fees
export const updateDoctorFees = asyncHandler(async (req, res) => {
  try {
    const { firstVisitFee, secondVisitFee, visitUnder7DaysFee, emergencyFee1, emergencyFee2 } = req.body;
    
    const doctor = await Doctor.findById(req.user.id);
    if (!doctor) {
      return res.status(404).json({ message: 'Doctor not found' });
    }
    
    doctor.fees = {
      firstVisitFee,
      secondVisitFee,
      visitUnder7DaysFee,
      emergencyFee1,
      emergencyFee2
    };
    
    await doctor.save();
    
    res
    .status(201)
    .json(
      new ApiResponse(200, doctor, "fees updated  successfully ")
    );
  } catch (error) {
    throw new AppError(400, "Unable to add fees ");
  }
});



export const deleteDoctor = asyncHandler(async (req, res, next) => {
  const doctor = await Doctor.findById(req.user.id);

  if (!doctor) {
    return next(new AppError("Doctor not found", 404));
  }

  await Doctor.findByIdAndDelete(req.user.id);

  res
    .status(200)
    .json(new ApiResponse(200, doctor, "Doctor deleted successfully"));
});


import axios from 'axios';

const AISENSY_API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY2ZjE0ZDI3NzlhOWNjMDZmMTI0ZmMyOCIsIm5hbWUiOiJZb3VyTGFiIiwiYXBwTmFtZSI6IkFpU2Vuc3kiLCJjbGllbnRJZCI6IjY2ZjE0ZDI2NzlhOWNjMDZmMTI0ZmMyMiIsImFjdGl2ZVBsYW4iOiJCQVNJQ19NT05USExZIiwiaWF0IjoxNzI3MDg5OTU5fQ.rfcannqNPX1x_0BT8dGDBCirih47-nu4uAawLQQct1k";

// Function to format phone number
const formatPhoneNumber = (phone) => {
  // Remove any non-numeric characters
  const cleaned = String(phone).replace(/\D/g, '');
  // Ensure it starts with the country code
  return cleaned.startsWith('91') ? cleaned : `91${cleaned}`;
};

// Function to send WhatsApp notification
const sendWhatsAppNotification = async (patientName, patientPhone, doctorName,dateAndTime) => {
  try {
    const formattedPhone = formatPhoneNumber(patientPhone);
    console.log('Sending notification to:', { patientName, formattedPhone, doctorName,dateAndTime });

    
    const payload = {
      apiKey: AISENSY_API_KEY,
      campaignName: "Appointment Notification To Patient",
      destination: formattedPhone,
      userName: "YourLab",
      templateParams: [
        patientName || "User",
        doctorName || "updated",
        dateAndTime
      ],
      source: "new-landing-page form",
      media: {},
      buttons: [],
      carouselCards: [],
      location: {},
      paramsFallbackValue: {
        FirstName: "user"
      }
    };

    console.log('Sending payload:', JSON.stringify(payload, null, 2));

    const response = await axios.post(
      'https://backend.aisensy.com/campaign/t1/api/v2',
      payload,
      {
        headers: {
          'Content-Type': 'application/json'
        }
      }
    );

    console.log('WhatsApp notification sent successfully:', response.data);
    return response.data;
  } catch (error) {
    console.error('Error sending WhatsApp notification:', {
      message: error.message,
      response: error.response?.data,
      status: error.response?.status
    });
    throw error;
  }
};

// Updated appointment status controller
export const updateAppointmentStatus = asyncHandler(async (req, res, next) => {
  try {
    const { appointmentId, doctorId, status } = req.body;

    // Validate input
    if (!appointmentId || !doctorId || !status) {
      return next(new AppError("Missing required fields", 400));
    }

    // Find doctor
    const doctor = await Doctor.findById(doctorId);
    if (!doctor) {
      return next(new AppError("Doctor not found", 404));
    }

    // Find appointment
    const appointment = await Appointment.findById(appointmentId)
    if (!appointment) {
      return next(new AppError("Appointment not found", 404));
    }

    // Update appointment status
    appointment.status = status;
    await appointment.save();

    // Get patient details from the populated appointment
    const patientName = `  ${ appointment?.patientName || 'Patient'}`;
    const patientPhone = appointment?.patientPhone;
    
    // Format doctor name with specialty
    const doctorName = `${doctor?.fullName || 'Dr.'} (${doctor?.specialist || 'Specialist'})`;
    
    // Format date and time with proper spacing
    const dateAndTime = `${appointment?.date || ''} (${appointment?.slotStartTime || ''} to ${appointment?.slotEndTime || ''})`;
    
    if (!patientPhone) {
      console.warn('No phone number found for patient');
      return res.status(200).json(
        new ApiResponse(
          200,
          appointment,
          "Appointment Updated Successfully but No Phone Number for Notification"
        )
      );
    }

    try {
      // Send WhatsApp notification
      await sendWhatsAppNotification(
        patientName,
        patientPhone,
        doctorName,
        dateAndTime
      );

      res.status(200).json(
        new ApiResponse(
          200,
          appointment,
          "Appointment Updated Successfully and Notification Sent"
        )
      );
    } catch (notificationError) {
      console.error('WhatsApp notification failed:', notificationError);
      
      // Still return success for the appointment update
      res.status(200).json(
        new ApiResponse(
          200,
          appointment,
          "Appointment Updated Successfully but Notification Failed"
        )
      );
    }
  } catch (error) {
    console.error('Error in updateAppointmentStatus:', error);
    next(error);
  }
});

// Test endpoint for WhatsApp notification
export const testWhatsAppNotification = asyncHandler(async (req, res) => {
  const { name, phone, status } = req.body;

  try {
    const result = await sendWhatsAppNotification(name, phone, status);
    res.status(200).json({
      success: true,
      message: "Test notification sent successfully",
      data: result
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to send test notification",
      error: error.response?.data || error.message
    });
  }
});

// Error handling middleware
export const errorHandler = (err, req, res, next) => {
  console.error('Error:', {
    message: err.message,
    stack: err.stack,
    status: err.status
  });

  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Internal server error',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
};