import { Router } from "express";
import {
  changePassword,
  forgotPassword,
  getAllDoctors,
  getLoggedInUserDetails,
  loginUser,
  logoutUser,
  registerUser,
  resetPassword,
  updateUser,
  getAppointments,
  newAppointmentByDoctor,
  activeStatus,
  updateAppointmentByDoctor,
  updateDoctorFees,
  tokenCheck,
  deleteDoctor,
  updateAppointmentStatus,
} from "../controllers/doctor.controllers.js";
import { isLoggedIn } from "../middlewares/auth.middlewares.js";
import upload from "../middlewares/multer.middleware.js";
import {
  allSchedule,
  createSchedule,
  getScheduleByDate,
  updateSchedule,
} from "../controllers/doctorSlot.controllers.js";
import { createLeave, deleteLeave, getLeaves } from "../controllers/doctorLeave.controllers.js";
import { authorizeRoles } from "../middlewares/admin.middleware.js";
import { reviewForSingleDoctor } from "../controllers/review.controllers.js";

const router = Router();

router.post("/register", upload.single("avatar"),isLoggedIn,authorizeRoles("Admin"), registerUser);
router.post("/login", loginUser);
router.post("/logout", logoutUser);
router.get("/me", isLoggedIn, getLoggedInUserDetails);
router.post("/reset", forgotPassword);
router.post("/reset/:resetToken", resetPassword);
router.post("/reset/token-check/:resetToken",tokenCheck)
router.post("/change-password", isLoggedIn, changePassword);
router.put("/update-profile", isLoggedIn, upload.single("avatar"), updateUser);
router.get("/myAppointments", isLoggedIn, getAppointments);

router.post("/newAppointmentByDoctor", isLoggedIn, newAppointmentByDoctor);
router.post(
  "/updateAppointmentByDoctor/:appointmentId",
  isLoggedIn,
  updateAppointmentByDoctor
);

router.post("/updateAppointmentStatus",isLoggedIn,updateAppointmentStatus)
router.get("/allDoctors", getAllDoctors);
router.post("/createSchedule", isLoggedIn, createSchedule);
router.post("updateSchedule", isLoggedIn, updateSchedule);

router.get("/allSchedule", isLoggedIn, allSchedule);
router.get('/getScheduleByDate/:date',isLoggedIn,getScheduleByDate)
router.post("/doctor-status", isLoggedIn, activeStatus);
router.post("/update-fees", isLoggedIn,updateDoctorFees);


router.post("/createLeave",isLoggedIn,createLeave)

router.delete("/deleteLeave/:leaveId",isLoggedIn,deleteLeave)
router.get("/allLeave",isLoggedIn,getLeaves)
router.delete('/delete',isLoggedIn,deleteDoctor)
router.get('/reviews/:doctorId',reviewForSingleDoctor)


export default router;
