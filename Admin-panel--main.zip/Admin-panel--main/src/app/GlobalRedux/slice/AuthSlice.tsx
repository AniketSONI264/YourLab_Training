import { createAsyncThunk, createSlice, PayloadAction } from "@reduxjs/toolkit";
import axiosInstance from "@/app/Helpers/axiosInstance";
import { Toast, toast } from "react-hot-toast";

interface UserState {
  data: Record<string, any>;
  doctors: Record<string, any>;
}

interface RegisterData {
  fullName: string;
  email: string;
  password: string;
  mobileNumber: string;
  address: string;
  specialist: string;
  description: string;
  fees: string;
  pincode: string;
  avatar: File | null;
}

const initialState: UserState = {
  data: {},
  doctors: {},
};

export const createDoctor = createAsyncThunk(
  "doctor/register",
  async (data: RegisterData) => {
    console.log(data);
    try {
      const res = axiosInstance.post("doctor/register", data, {
        withCredentials: true,
      });
      toast.promise(res, {
        loading: "Wait! creating doctor ",
        success: (data) => data?.data?.message,
        error: "Failed to create Doctors",
      });
      // Extract the token from the response
      const response = await res;

      return response.data;
    } catch (error: any) {
      throw error;
    } finally {
      console.log("finally");
    }
  }
);

export const allDoctors = createAsyncThunk("doctor/allDoctors", async () => {
  try {
    const res = axiosInstance.get("doctor/allDoctors", {
      withCredentials: true,
    });

    toast.promise(res, {
      loading: "Wait! fetching doctors",
      success: (data) => data?.data?.message,
      error: "Failed to fetch doctors",
    });

    // Extract the token from the response
    const response = await res;

    return response.data;
  } catch (error: any) {
    throw error;
  } finally {
    console.log("finally");
  }
});

export const allPatientEnquiry = createAsyncThunk(
  "admin/allPatientEnquiry",
  async () => {
    try {
      const res = axiosInstance.get("admin/getAllPatientEnquiry", {
        withCredentials: true,
      });

      toast.promise(res, {
        loading: "Fetching enquiries ",
        success: (data) => data?.data?.message,
        error: "Failed to find enquiry ",
      });

      // Extract the token from the response
      const response = await res;

      return response.data;
    } catch (error: any) {
      throw error;
    } finally {
      console.log("finally");
    }
  }
);

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(createDoctor.fulfilled, (state, action: PayloadAction<any>) => {
        state.data = action?.payload?.data;
      })
      .addCase(allDoctors.fulfilled, (state, action: PayloadAction<any>) => {
        state.doctors = action?.payload?.data;
      });
  },
});

export default authSlice.reducer;
