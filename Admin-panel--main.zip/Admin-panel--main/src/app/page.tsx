"use client"
import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import ApplyDoctor from './components/AddDoctor';
import DoctorList from './components/DoctorList';
import UploadProfile from './components/UploadProfile';

const MainPage = () => {


  

  return (
    <DoctorList/>
  );
};

export default MainPage;
