'use client'

import React from 'react';
import AddDoctor from '../components/AddDoctor';
import Sidebar from '../components/Sidebar';

const Page: React.FC = () => {
  return (
    <AddDoctor/>
  );
};

export default Page;