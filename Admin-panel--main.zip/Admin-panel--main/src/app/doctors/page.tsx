'use client'
import React from 'react';

import Sidebar from '../components/Sidebar';
import DoctorList from '../components/DoctorList';

const Page: React.FC = () => {
  return (
    <DoctorList/>
  );
};

export default Page;