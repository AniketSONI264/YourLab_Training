
const FormHead = () => {
    return (
      <div className="my-[1rem]">
        <h1 className="text-center font-bold text-3xl">Patient Details</h1>
      </div>
    )
  }
  
  export default FormHead
  