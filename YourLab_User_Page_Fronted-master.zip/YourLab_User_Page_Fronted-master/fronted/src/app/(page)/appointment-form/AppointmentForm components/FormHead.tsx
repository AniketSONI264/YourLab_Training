
const FormHead = () => {
    return (
      <div className="mb-[1rem] mt-[0.5rem]">
        <h1 className="text-center font-bold text-3xl">Patient Details</h1>
      </div>
    )
  }
  
  export default FormHead
  